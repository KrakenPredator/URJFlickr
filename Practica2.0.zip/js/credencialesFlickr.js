{
    var api_key = "262eb8b77ba0490583d5a8eaadb564c5";
    var user_id = "37496041@N06";
    var mi_id = "86191686@N06";
}
